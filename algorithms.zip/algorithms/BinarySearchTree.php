
<?php

// ==========================================
// BINARY SEARCH TREE NODE
// ==========================================

class BSTNode
{
    public int $key;
    public array $data;

    public ?BSTNode $left = null;
    public ?BSTNode $right = null;

    public function __construct(int $key, array $data)
    {
        $this->key = $key;
        $this->data = $data;
    }
}

// ==========================================
// BINARY SEARCH TREE
// ==========================================

class BinarySearchTree
{
    private ?BSTNode $root = null;

    // Insert inventory item into BST
    public function insert(int $key, array $data): void
    {
        $this->root = $this->insertNode(
            $this->root,
            $key,
            $data
        );
    }

    private function insertNode(
        ?BSTNode $node,
        int $key,
        array $data
    ): BSTNode {

        if ($node === null) {
            return new BSTNode($key, $data);
        }

        if ($key < $node->key) {

            $node->left = $this->insertNode(
                $node->left,
                $key,
                $data
            );

        } elseif ($key > $node->key) {

            $node->right = $this->insertNode(
                $node->right,
                $key,
                $data
            );

        } else {

            // Update existing inventory record
            $node->data = $data;
        }

        return $node;
    }

    // Search inventory item by ID
    public function search(int $key): ?array
    {
        $current = $this->root;

        while ($current !== null) {

            if ($key === $current->key) {
                return $current->data;
            }

            if ($key < $current->key) {
                $current = $current->left;
            } else {
                $current = $current->right;
            }
        }

        return null;
    }

    // Return inventory items in ascending ID order
    public function inOrderTraversal(): array
    {
        $result = [];

        $this->traverse($this->root, $result);

        return $result;
    }

    private function traverse(
        ?BSTNode $node,
        array &$result
    ): void {

        if ($node === null) {
            return;
        }

        $this->traverse($node->left, $result);

        $result[] = $node->data;

        $this->traverse($node->right, $result);
    }
}