
<?php

class MergeSort
{
    public static function sort(
        array $items,
        string $field,
        string $order = 'ASC'
    ): array {

        $count = count($items);

        if ($count <= 1) {
            return $items;
        }

        $middle = (int) ($count / 2);

        $left = array_slice($items, 0, $middle);
        $right = array_slice($items, $middle);

        $left = self::sort($left, $field, $order);
        $right = self::sort($right, $field, $order);

        return self::merge($left, $right, $field, $order);
    }

    private static function merge(
        array $left,
        array $right,
        string $field,
        string $order
    ): array {

        $result = [];
        $i = 0;
        $j = 0;

        while ($i < count($left) && $j < count($right)) {

            $valueLeft = $left[$i][$field];
            $valueRight = $right[$j][$field];

            if (is_numeric($valueLeft) && is_numeric($valueRight)) {
                $comparison = (float) $valueLeft <=> (float) $valueRight;
            } else {
                $comparison = strcasecmp(
                    (string) $valueLeft,
                    (string) $valueRight
                );
            }

            if ($order === 'DESC') {
                $comparison *= -1;
            }

            if ($comparison <= 0) {
                $result[] = $left[$i];
                $i++;
            } else {
                $result[] = $right[$j];
                $j++;
            }
        }

        while ($i < count($left)) {
            $result[] = $left[$i];
            $i++;
        }

        while ($j < count($right)) {
            $result[] = $right[$j];
            $j++;
        }

        return $result;
    }
}
