
<?php

class Queue
{
    private array $items = [];
    private int $front = 0;
    private int $rear = 0;

    // Add an order to the rear of the queue.
    public function enqueue(array $order): void
    {
        $this->items[$this->rear] = $order;
        $this->rear++;
    }

    // Remove and return the first order.
    public function dequeue(): ?array
    {
        if ($this->isEmpty()) {
            return null;
        }

        $order = $this->items[$this->front];

        unset($this->items[$this->front]);

        $this->front++;

        return $order;
    }

    // View the first order without removing it.
    public function peek(): ?array
    {
        if ($this->isEmpty()) {
            return null;
        }

        return $this->items[$this->front];
    }

    // Check whether the queue is empty.
    public function isEmpty(): bool
    {
        return $this->front === $this->rear;
    }

    // Return the number of pending orders.
    public function size(): int
    {
        return $this->rear - $this->front;
    }

    // Return all pending orders.
    public function getAll(): array
    {
        return array_values($this->items);
    }
}
