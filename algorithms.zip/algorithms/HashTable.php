
<?php

class HashTable
{
    private array $table = [];

    // Insert an inventory item using its name as the key.
    public function insert(string $key, array $data): void
    {
        $key = strtolower(trim($key));

        $this->table[$key] = $data;
    }

    // Search for an inventory item by name.
    public function search(string $key): ?array
    {
        $key = strtolower(trim($key));

        return $this->table[$key] ?? null;
    }

    // Return all stored inventory records.
    public function getAll(): array
    {
        return array_values($this->table);
    }

    // Return the number of stored records.
    public function size(): int
    {
        return count($this->table);
    }
}
