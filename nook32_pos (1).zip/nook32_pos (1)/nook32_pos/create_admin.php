
<?php
require_once 'config/database.php';

$fullName = 'Nook32 Administrator';
$username = 'admin';
$plainPassword = 'Admin123!';

// Check if the username already exists
$stmt = $conn->prepare(
    "SELECT user_id FROM users WHERE username = ?"
);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "The username 'admin' already exists. No new account was created.";
} else {
    $hashedPassword = password_hash(
        $plainPassword,
        PASSWORD_DEFAULT
    );

    $role = 'admin';

    $stmt = $conn->prepare(
        "INSERT INTO users (full_name, username, password, role)
         VALUES (?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "ssss",
        $fullName,
        $username,
        $hashedPassword,
        $role
    );

    $stmt->execute();

    echo "Admin account created successfully!";
}

$stmt->close();
$conn->close();
?>
