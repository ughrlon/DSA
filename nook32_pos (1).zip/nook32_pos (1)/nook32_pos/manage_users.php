<?php
require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

$sql = "SELECT user_id, full_name, username, role, created_at
        FROM users
        ORDER BY user_id ASC";

$result = $conn->query($sql);

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        .container {
            max-width: 1100px;
            margin: auto;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0 0 8px;
        }

        header p {
            margin: 0;
            color: #654633;
        }

        .card {
            padding: 24px;
            background: #fffdf9;
            border: 1px solid #dfcbb7;
            border-radius: 16px;
            overflow-x: auto;
        }

        a {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 24px;
            background: #654633;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th, td {
            padding: 14px 12px;
            border-bottom: 1px solid #eadfd2;
            text-align: left;
        }

        th {
            background: #f7f1e8;
        }

        .role {
            font-weight: bold;
            text-transform: capitalize;
        }

        .empty {
            padding: 24px;
            text-align: center;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            .card {
                padding: 15px;
            }
        }

                .users-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .add-user-btn {
            display: inline-block;
            background: #654633;
            color: white;
            padding: 12px 20px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: bold;
        }

        .add-user-btn:hover {
            background: #39271f;
        }
    </style>
</head>

<body>
<div class="container">

    <header>
        <div>
            <h1>NOOK32 COFFEE</h1>
            <p>Admin Account Management</p>
        </div>

        <a href="index.php">Back to POS</a>
    </header>

    <section class="card">
        <div class="users-heading">
    <div>
        <h2>Registered Users</h2>
        <p>View the accounts registered in your POS system.</p>
    </div>

    <a href="add_user.php" class="add-user-btn">
        + Add New User
    </a>
</div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th>Action</th>
                    <th>Delete</th>
                </tr>
            </thead>

            <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($user = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($user['user_id']) ?></td>
                        <td><?= e($user['full_name']) ?></td>
                        <td><?= e($user['username']) ?></td>
                        <td class="role"><?= e($user['role']) ?></td>
                        <td><?= e($user['created_at']) ?></td>
                        <td>
                            <?php if ((int)$user['user_id'] !== (int)$_SESSION['user_id']): ?>
                                <form
                                    method="POST"
                                    action="delete_user.php"
                                    onsubmit="return confirm('Are you sure you want to delete this account?');"
                                >
                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= e($_SESSION['csrf_token']) ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="user_id"
                                        value="<?= e($user['user_id']) ?>"
                                    >

                                    <button type="submit">Delete</button>
                                </form>
                            <?php else: ?>
                                <span>Current Account</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ((int)$user['user_id'] !== (int)$_SESSION['user_id']): ?>
                                <a href="reset_password.php?id=<?= e($user['user_id']) ?>">
                                    Reset Password
                                </a>
                            <?php else: ?>
                                <span>Current Account</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="empty">
                        No user accounts found.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </section>

</div>
</body>
</html>
