
<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

session_start();
require_once __DIR__ . '/config/database.php';

$error = '';

$selectedRole = $_POST['role'] ?? 'cashier';

if (!in_array($selectedRole, ['cashier', 'admin'], true)) {
    $selectedRole = 'cashier';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {

        $error = 'Please enter your username and password.';

    } else {

        try {
            $stmt = $conn->prepare(
                "SELECT user_id, full_name, username, password, role
                 FROM users
                 WHERE username = ?
                 LIMIT 1"
            );

            $stmt->bind_param("s", $username);
            $stmt->execute();

            $stmt->bind_result(
                $userId,
                $fullName,
                $dbUsername,
                $hashedPassword,
                $role
            );

            if ($stmt->fetch() && password_verify($password, $hashedPassword)) {

                $stmt->close();

                if (strtolower($role) !== $selectedRole) {

                    $error = 'This account does not belong to the selected login type.';

                } else {

                    session_regenerate_id(true);

                    $_SESSION['user_id'] = $userId;
                    $_SESSION['full_name'] = $fullName;
                    $_SESSION['username'] = $dbUsername;
                    $_SESSION['role'] = strtolower($role);

                    header('Location: index.php');
                    exit;
                }

            } else {

                $stmt->close();
                $error = 'Invalid username or password.';

            }

        } catch (Throwable $e) {

            error_log('Login error: ' . $e->getMessage());
            $error = 'A login error occurred. Please try again.';

        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f4eee6;
            color: #3b2920;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
            padding: 35px;
            background: #fffdf9;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(59, 41, 32, 0.12);
        }

        .brand {
            text-align: center;
            margin-bottom: 28px;
        }

        .brand h1 {
            margin-bottom: 8px;
            color: #6f4e37;
        }

        .brand p {
            margin: 0;
            color: #806e61;
        }

        /* Cashier and Admin tabs */

        .role-tabs {
            display: flex;
            margin: 25px 0;
            border-bottom: 1px solid #e5d9ce;
        }

        .role-tab {
            flex: 1;
            padding: 12px 5px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            border: none;
            border-bottom: 3px solid transparent;
            background: transparent;
            color: #806e61;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
        }

        .role-tab svg {
            width: 18px;
            height: 18px;
        }

        .role-tab.active {
            color: #3b2920;
            border-bottom-color: #6f4e37;
        }

        .role-tab:hover {
            color: #6f4e37;
        }

        /* Form labels */

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        /* Input with icons */

        .input-wrapper {
            position: relative;
        }

        .input-wrapper > svg {
            position: absolute;
            left: 13px;
            top: 50%;
            transform: translateY(-50%);
            width: 19px;
            height: 19px;
            color: #806e61;
            pointer-events: none;
        }

        input {
            width: 100%;
            padding: 12px 42px;
            border: 1px solid #d8c7b8;
            border-radius: 8px;
            font-size: 15px;
            background: #fffdf9;
            color: #3b2920;
        }

        input:focus {
            outline: 2px solid #a67c52;
            border-color: #a67c52;
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 30px;
            height: 30px;
            padding: 5px;
            margin: 0;
            border: none;
            background: transparent;
            color: #806e61;
            cursor: pointer;
        }

        .password-toggle svg {
            width: 19px;
            height: 19px;
        }

        .password-toggle:hover {
            color: #6f4e37;
        }

        /* Selected role description */

        .role-description {
            margin-top: 5px;
            color: #806e61;
            font-size: 12px;
            text-align: right;
        }

        /* Login button */

        .login-button {
            width: 100%;
            margin-top: 24px;
            padding: 13px;
            border: none;
            border-radius: 8px;
            background: #6f4e37;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .login-button:hover {
            background: #543927;
        }

        .error {
            padding: 11px;
            margin-bottom: 16px;
            border-radius: 8px;
            background: #fbe9e7;
            color: #a12b21;
            font-size: 13px;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 25px;
            }

            .role-tab {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

<main class="login-container">

    <div class="brand">
        <h1>Nook32 Coffee</h1>
        <p>POS and Sales Management System</p>
    </div>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <!-- Account type selection -->

    <div class="role-tabs">

        <button
            type="button"
            id="cashierTab"
            class="role-tab <?= $selectedRole === 'cashier' ? 'active' : '' ?>"
            onclick="selectRole('cashier')"
        >
            <svg viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="4" width="18" height="13" rx="1"></rect>
                <path d="M8 21h8M12 17v4"></path>
            </svg>
            Cashier
        </button>

        <button
            type="button"
            id="adminTab"
            class="role-tab <?= $selectedRole === 'admin' ? 'active' : '' ?>"
            onclick="selectRole('admin')"
        >
            <svg viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"></path>
            </svg>
            Admin
        </button>

    </div>

    <form method="POST" action="login.php">

        <input
            type="hidden"
            name="role"
            id="selectedRole"
            value="<?= htmlspecialchars($selectedRole, ENT_QUOTES, 'UTF-8') ?>"
        >

        <!-- Username -->

        <label for="username">Username</label>

        <div class="input-wrapper">

            <svg viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>

            <input
                type="text"
                id="username"
                name="username"
                placeholder="Enter your username"
                autocomplete="username"
                value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >

        </div>

        <!-- Password -->

        <label for="password">Password</label>

        <div class="input-wrapper">

            <svg viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>

            <input
                type="password"
                id="password"
                name="password"
                placeholder="Enter your password"
                autocomplete="current-password"
                required
            >

            <button
                type="button"
                class="password-toggle"
                onclick="togglePassword()"
                aria-label="Show password"
                id="passwordToggle"
            >
                <svg id="eyeIcon" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor"
                     stroke-width="2" stroke-linecap="round"
                     stroke-linejoin="round">
                    <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                </svg>
            </button>

        </div>

        <div class="role-description" id="roleDescription">
            Front Counter POS
        </div>

        <button type="submit" class="login-button" id="loginButton">
            Log In
        </button>

    </form>

</main>

<script>

    function selectRole(role) {

        document.getElementById('selectedRole').value = role;

        document.getElementById('cashierTab')
            .classList.toggle('active', role === 'cashier');

        document.getElementById('adminTab')
            .classList.toggle('active', role === 'admin');

        document.getElementById('roleDescription').textContent =
            role === 'cashier' ? 'Front Counter POS' : 'Administration';

        document.getElementById('loginButton').textContent =
            role === 'cashier' ? 'Log In as Cashier' : 'Log In as Admin';
    }

    function togglePassword() {

        const password = document.getElementById('password');
        const eyeIcon = document.getElementById('eyeIcon');
        const toggle = document.getElementById('passwordToggle');

        if (password.type === 'password') {

            password.type = 'text';

            eyeIcon.innerHTML = `
                <path d="M3 3l18 18"></path>
                <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"></path>
                <path d="M9.9 5.2A10.7 10.7 0 0 1 12 5
                    c6.5 0 10 7 10 7a14 14 0 0 1-3 3.8"></path>
                <path d="M6.2 6.2C3.5 8 2 12 2 12s3.5 7 10 7
                    c1.5 0 2.8-.3 4-.8"></path>
            `;

            toggle.setAttribute('aria-label', 'Hide password');

        } else {

            password.type = 'password';

            eyeIcon.innerHTML = `
                <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"></path>
                <circle cx="12" cy="12" r="3"></circle>
            `;

            toggle.setAttribute('aria-label', 'Show password');
        }
    }

    selectRole(document.getElementById('selectedRole').value);

</script>

</body>
</html>
