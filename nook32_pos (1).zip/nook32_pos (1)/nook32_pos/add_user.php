<?php
require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check the form's security token
    if (
        !isset($_POST['csrf_token'], $_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        http_response_code(403);
        exit('Invalid security token. Please reload the page and try again.');
    }

    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'cashier';

    if ($fullName === '' || $username === '' || $password === '') {
        $message = 'Please complete all required fields.';
        $messageType = 'error';
    } elseif (!in_array($role, ['admin', 'cashier'], true)) {
        $message = 'Invalid user role.';
        $messageType = 'error';
    } elseif (strlen($password) < 8) {
        $message = 'Password must be at least 8 characters long.';
        $messageType = 'error';
    } else {
        // Check whether the username is already used
        $check = $conn->prepare(
            'SELECT user_id FROM users WHERE username = ?'
        );
        $check->bind_param('s', $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = 'That username already exists. Please choose another.';
            $messageType = 'error';
        } else {
            // Hash the password before saving it
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare(
                'INSERT INTO users (full_name, username, password, role)
                 VALUES (?, ?, ?, ?)'
            );
            $stmt->bind_param(
                'ssss',
                $fullName,
                $username,
                $hashedPassword,
                $role
            );

            if ($stmt->execute()) {
                $message = 'User account created successfully.';
                $messageType = 'success';
            } else {
                $message = 'Unable to create the account. Please try again.';
                $messageType = 'error';
            }

            $stmt->close();
        }

        $check->close();
    }
}

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 16px;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        .container {
            max-width: 650px;
            margin: 0 auto;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0 0 6px;
        }

        .subtitle {
            margin: 0;
            color: #654633;
        }

        .card {
            background: #fffdf9;
            padding: 28px;
            border: 1px solid #e4d0bd;
            border-radius: 16px;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #d8c3b0;
            border-radius: 8px;
            font-size: 15px;
        }

        button, .back {
            display: inline-block;
            border: none;
            border-radius: 25px;
            padding: 12px 20px;
            background: #654633;
            color: white;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        button {
            width: 100%;
            margin-top: 22px;
            font-size: 15px;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .success {
            background: #e5f4e8;
            color: #245c32;
        }

        .error {
            background: #fbe8e5;
            color: #8b2e22;
        }

        .note {
            font-size: 13px;
            color: #765f50;
            margin-top: 7px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div>
            <h1>NOOK32 COFFEE</h1>
            <p class="subtitle">Add User Account</p>
        </div>

        <a class="back" href="manage_users.php">Back</a>
    </div>

    <div class="card">
        <h2>Create a New Account</h2>

        <?php if ($message !== ''): ?>
            <div class="message <?= e($messageType) ?>">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION['csrf_token']) ?>"
            >

            <label for="full_name">Full Name</label>
            <input
                type="text"
                id="full_name"
                name="full_name"
                required
            >

            <label for="username">Username</label>
            <input
                type="text"
                id="username"
                name="username"
                required
            >

            <label for="password">Temporary Password</label>
            <input
                type="password"
                id="password"
                name="password"
                minlength="8"
                required
            >
            <p class="note">Use at least 8 characters. Give the password privately to the account holder.</p>

            <label for="role">Account Role</label>
            <select id="role" name="role" required>
                <option value="cashier" selected>Cashier</option>
                <option value="admin">Admin</option>
            </select>

            <button type="submit">Create Account</button>
        </form>
    </div>
</div>
</body>
</html>