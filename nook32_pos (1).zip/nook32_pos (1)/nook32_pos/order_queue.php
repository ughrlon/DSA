
<?php

require_once __DIR__ . '/auth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Allow both admin and cashier accounts.
if (
    !isset($_SESSION['user_id']) ||
    !in_array(
        strtolower($_SESSION['role'] ?? ''),
        ['admin', 'cashier'],
        true
    )
) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/algorithms/Queue.php';

// Generate CSRF token.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

$message = '';
$messageType = 'success';

// ==========================================
// PROCESS QUEUE ACTIONS
// ==========================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        $token = $_POST['csrf_token'] ?? '';

        if (
            !is_string($token) ||
            !hash_equals($_SESSION['csrf_token'], $token)
        ) {
            throw new RuntimeException(
                'Invalid security token. Please refresh the page.'
            );
        }

        $action = $_POST['action'] ?? '';

        $orderId = filter_var(
            $_POST['order_id'] ?? null,
            FILTER_VALIDATE_INT
        );

        if ($orderId === false || $orderId === null || $orderId <= 0) {
            throw new InvalidArgumentException(
                'Invalid order ID.'
            );
        }

        $conn->begin_transaction();
        $transactionStarted = true;

        if ($action === 'start') {

            // Do not allow another order while one is processing.
            $processingResult = $conn->query(
                "SELECT order_id
                 FROM orders
                 WHERE payment_status = 'paid'
                   AND order_status = 'processing'
                 LIMIT 1
                 FOR UPDATE"
            );

            if ($processingResult->fetch_assoc()) {
                throw new RuntimeException(
                    'Finish the current processing order first.'
                );
            }

            // Get the oldest paid pending order.
            $nextResult = $conn->query(
                "SELECT order_id
                 FROM orders
                 WHERE payment_status = 'paid'
                   AND order_status = 'pending'
                 ORDER BY order_date ASC, order_id ASC
                 LIMIT 1
                 FOR UPDATE"
            );

            $nextOrder = $nextResult->fetch_assoc();

            if (
                !$nextOrder ||
                (int) $nextOrder['order_id'] !== $orderId
            ) {
                throw new RuntimeException(
                    'FIFO rule: You must process the oldest paid order first.'
                );
            }

            $stmt = $conn->prepare(
                "UPDATE orders
                 SET order_status = 'processing'
                 WHERE order_id = ?
                   AND payment_status = 'paid'
                   AND order_status = 'pending'"
            );

            $stmt->bind_param('i', $orderId);
            $stmt->execute();

            if ($stmt->affected_rows !== 1) {
                throw new RuntimeException(
                    'The order could not be started.'
                );
            }

            $message = 'Order #' . $orderId .
                       ' is now being processed.';

        } elseif ($action === 'complete') {

            // Only the current processing order can be completed.
            $currentResult = $conn->query(
                "SELECT order_id
                 FROM orders
                 WHERE payment_status = 'paid'
                   AND order_status = 'processing'
                 ORDER BY order_date ASC, order_id ASC
                 LIMIT 1
                 FOR UPDATE"
            );

            $currentOrder = $currentResult->fetch_assoc();

            if (
                !$currentOrder ||
                (int) $currentOrder['order_id'] !== $orderId
            ) {
                throw new RuntimeException(
                    'Only the current processing order can be completed.'
                );
            }

            $stmt = $conn->prepare(
                "UPDATE orders
                 SET order_status = 'completed'
                 WHERE order_id = ?
                   AND payment_status = 'paid'
                   AND order_status = 'processing'"
            );

            $stmt->bind_param('i', $orderId);
            $stmt->execute();

            if ($stmt->affected_rows !== 1) {
                throw new RuntimeException(
                    'The order could not be completed.'
                );
            }

            $message = 'Order #' . $orderId .
                       ' completed successfully.';

        } else {

            throw new InvalidArgumentException(
                'Invalid queue action.'
            );
        }

        $conn->commit();
        $transactionStarted = false;

    } catch (Throwable $e) {

        if ($transactionStarted) {
            $conn->rollback();
        }
    

        error_log('NOOK32 Queue error: ' . $e->getMessage());

        $message = $e->getMessage();
        $messageType = 'error';
        }
    }

// ==========================================
// LOAD PAID ORDERS INTO FIFO QUEUE
// ==========================================

$queue = new Queue();

$sql = "
    SELECT
        o.order_id,
        o.order_date,
        o.total_amount,
        o.payment_method,
        o.order_status,

        GROUP_CONCAT(
            CONCAT(
                oi.product_name,
                ' × ',
                oi.quantity
            )
            ORDER BY oi.order_item_id
            SEPARATOR ', '
        ) AS items

    FROM orders o

    LEFT JOIN order_items oi
        ON o.order_id = oi.order_id

    WHERE o.payment_status = 'paid'
      AND o.order_status IN ('pending', 'processing')

    GROUP BY
        o.order_id,
        o.order_date,
        o.total_amount,
        o.payment_method,
        o.order_status

    ORDER BY
        o.order_date ASC,
        o.order_id ASC
";

$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $queue->enqueue($row);
}

$orders = $queue->getAll();

// Find the current processing order.
$processingOrderId = null;

foreach ($orders as $order) {
    if ($order['order_status'] === 'processing') {
        $processingOrderId = (int) $order['order_id'];
        break;
    }
}

$queueCount = $queue->size();
$pendingCount = 0;

foreach ($orders as $order) {
    if ($order['order_status'] === 'pending') {
        $pendingCount++;
    }
}

$nextPendingOrderId = null;

if ($processingOrderId === null) {
    foreach ($orders as $order) {
        if ($order['order_status'] === 'pending') {
            $nextPendingOrderId = (int) $order['order_id'];
            break;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Order Queue | Nook32 Coffee</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 30px;
    font-family: Arial, sans-serif;
    background: #f7f1e8;
    color: #39271f;
}

.container {
    max-width: 1200px;
    margin: auto;
}

header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 25px;
}

header h1 {
    margin: 0;
}

header p {
    color: #806c5d;
}

nav {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

nav a {
    padding: 10px 14px;
    border: 1px solid #dfcbb7;
    border-radius: 8px;
    color: #39271f;
    text-decoration: none;
    background: #fffdf9;
}

nav a:hover {
    background: #dfcbb7;
}

.stats {
    display: grid;
    grid-template-columns: repeat(
        auto-fit,
        minmax(180px, 1fr)
    );
    gap: 18px;
    margin-bottom: 25px;
}

.card {
    background: #fffdf9;
    border: 1px solid #e8dbcd;
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 20px;
    box-shadow: 0 4px 12px rgba(57,39,31,0.05);
}

.card p {
    color: #806c5d;
}

.card h2 {
    margin-top: 0;
}

.stat-number {
    font-size: 28px;
    font-weight: bold;
    margin: 0;
    color: #654633;
}

.order-card {
    border: 1px solid #e8dbcd;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 15px;
    background: #fffdf9;
}

.order-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.order-top h3 {
    margin: 0;
}

.order-details {
    color: #806c5d;
    line-height: 1.8;
}

.status {
    display: inline-block;
    padding: 7px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.pending {
    background: #fff0c2;
    color: #795b00;
}

.processing {
    background: #dce8fa;
    color: #234e85;
}

.message {
    padding: 13px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.message.success {
    background: #dcefdc;
    color: #24632b;
}

.message.error {
    background: #f8d7da;
    color: #842029;
}

button {
    border: none;
    padding: 11px 17px;
    border-radius: 8px;
    background: #654633;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #39271f;
}

button:disabled {
    background: #aaa;
    cursor: not-allowed;
}

.action-form {
    margin-top: 15px;
}

.empty {
    text-align: center;
    padding: 40px;
    color: #806c5d;
}

.fifo-label {
    color: #654633;
    font-size: 12px;
    font-weight: bold;
    margin-bottom: 8px;
}

@media (max-width: 600px) {
    body {
        padding: 15px;
    }
}

</style>

</head>

<body>

<div class="container">

<header>

    <div>
        <h1>NOOK32 COFFEE</h1>
        <p>FIFO Order Queue Management</p>
    </div>

    <nav>
        <a href="index.php">POS Menu</a>
        <a href="order_history.php">Order History</a>
        <a href="inventory.php">Inventory</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>

</header>

<?php if ($message !== ''): ?>

    <div class="message <?= e($messageType) ?>">
        <?= e($message) ?>
    </div>

<?php endif; ?>

<!-- QUEUE STATISTICS -->

<section class="stats">

    <div class="card">
        <p>Total Orders in Queue</p>
        <h2 class="stat-number">
            <?= $queueCount ?>
        </h2>
    </div>

    <div class="card">
        <p>Waiting Orders</p>
        <h2 class="stat-number">
            <?= $pendingCount ?>
        </h2>
    </div>

    <div class="card">
        <p>Currently Processing</p>
        <h2 class="stat-number">
            <?= $processingOrderId !== null ? 1 : 0 ?>
        </h2>
    </div>

</section>

<!-- FIFO QUEUE -->

<section class="card">

    <h2>Customer Order Queue</h2>

    <p>
        Orders are processed using First In, First Out (FIFO).
        The oldest paid order must be handled first.
    </p>

    <?php if ($queueCount > 0): ?>

        <?php foreach ($orders as $index => $order): ?>

            <?php
                $orderId = (int) $order['order_id'];
                $status = $order['order_status'];
            ?>

            <article class="order-card">

                <div class="order-top">

                    <h3>
                        Order #<?= $orderId ?>
                    </h3>

                    <span class="status <?= e($status) ?>">
                        <?= strtoupper(e($status)) ?>
                    </span>

                </div>

                <p class="fifo-label">
                    QUEUE POSITION <?= $index + 1 ?>
                </p>

                <div class="order-details">

                    <strong>Products:</strong>
                    <?= e($order['items'] ?? 'No items') ?>

                    <br>

                    <strong>Total:</strong>
                    ₱<?= number_format(
                        (float) $order['total_amount'],
                        2
                    ) ?>

                    <br>

                    <strong>Payment:</strong>
                    <?= e(strtoupper($order['payment_method'])) ?>

                    <br>

                    <strong>Order Date:</strong>
                    <?= e(date(
                        'M d, Y h:i A',
                        strtotime($order['order_date'])
                    )) ?>

                </div>

                <?php if (
                    $status === 'processing' &&
                    $processingOrderId === $orderId
                ): ?>

                    <form method="POST" class="action-form">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION['csrf_token']) ?>"
                        >

                        <input
                            type="hidden"
                            name="order_id"
                            value="<?= $orderId ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="complete"
                        >

                        <button type="submit">
                            Complete Order
                        </button>

                    </form>

                <?php elseif (
                    $status === 'pending' &&
                    $nextPendingOrderId === $orderId
                ): ?>

                    <form method="POST" class="action-form">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION['csrf_token']) ?>"
                        >

                        <input
                            type="hidden"
                            name="order_id"
                            value="<?= $orderId ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="start"
                        >

                        <button type="submit">
                            Start Processing
                        </button>

                    </form>

                <?php else: ?>

                    <p>
                        <strong>Waiting for the previous order.</strong>
                    </p>

                <?php endif; ?>

            </article>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">

            <h3>No pending orders</h3>

            <p>
                New paid customer orders will automatically
                appear here.
            </p>

        </div>

    <?php endif; ?>

</section>

</div>

</body>
</html>
