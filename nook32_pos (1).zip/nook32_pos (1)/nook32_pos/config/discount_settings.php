
<?php

/*
|--------------------------------------------------------------------------
| NOOK32 Coffee Discount Settings
|--------------------------------------------------------------------------
| Set this only after confirming the business's BIR registration.
|
| Allowed values:
| VAT       = VAT-registered
| NON_VAT   = Non-VAT registered
| UNCONFIRMED = Do not process statutory discounts yet
*/

define('NOOK32_VAT_STATUS', 'VAT');

define('NOOK32_SC_PWD_DISCOUNT_RATE', 0.20);

define('NOOK32_VAT_RATE', 0.12);
