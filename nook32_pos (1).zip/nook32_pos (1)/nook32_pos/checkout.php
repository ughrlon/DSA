<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

// ==========================================
// JSON RESPONSE
// ==========================================

function respond(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data);
    exit;
}

// ==========================================
// LOGIN VALIDATION
// ==========================================

if (!isset($_SESSION['user_id'])) {
    respond([
        'success' => false,
        'message' => 'Your session has expired. Please log in again.'
    ], 401);
}

// ==========================================
// REQUIRED FILES
// ==========================================

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/discount_settings.php';
require_once __DIR__ . '/classes/Database.php';
require_once __DIR__ . '/classes/OrderManager.php';

// ==========================================
// REQUEST VALIDATION
// ==========================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond([
        'success' => false,
        'message' => 'Invalid request method.'
    ], 405);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!is_array($data)) {
    respond([
        'success' => false,
        'message' => 'Invalid checkout data.'
    ], 400);
}

$items = $data['items'] ?? [];
$paymentMethod = $data['payment_method'] ?? '';
$paymentReference = $data['payment_reference'] ?? null;
$cashReceivedInput = $data['cash_received'] ?? null;

// ==========================================
// CART VALIDATION
// ==========================================

if (!is_array($items) || empty($items)) {
    respond([
        'success' => false,
        'message' => 'Your cart is empty.'
    ], 400);
}

if (!in_array($paymentMethod, ['cash', 'qr'], true)) {
    respond([
        'success' => false,
        'message' => 'Please select a valid payment method.'
    ], 400);
}

// ==========================================
// DISCOUNT INPUTS
// ==========================================

$discountType = $data['discount_type'] ?? 'none';

$discountCustomerName =
    $data['discount_customer_name'] ?? null;

$discountIdNumber =
    $data['discount_id_number'] ?? null;

$exclusiveUseConfirmed =
    $data['exclusive_use_confirmed'] ?? false;

if (!in_array($discountType, ['none', 'pwd', 'senior'], true)) {
    respond([
        'success' => false,
        'message' => 'Invalid discount type.'
    ], 400);
}

$discountAmount = 0.00;
$vatExemptAmount = 0.00;

// ==========================================
// VALIDATE DISCOUNT INFORMATION
// ==========================================

if ($discountType !== 'none') {

    if (
        !is_string($discountCustomerName) ||
        trim($discountCustomerName) === '' ||
        strlen(trim($discountCustomerName)) > 150
    ) {
        respond([
            'success' => false,
            'message' => 'Enter a valid customer full name.'
        ], 400);
    }

    if (
        !is_string($discountIdNumber) ||
        trim($discountIdNumber) === '' ||
        strlen(trim($discountIdNumber)) > 80
    ) {
        respond([
            'success' => false,
            'message' => 'Enter a valid PWD or Senior Citizen ID number.'
        ], 400);
    }

    if ($exclusiveUseConfirmed !== true) {
        respond([
            'success' => false,
            'message' => 'Please confirm that the purchase is for the exclusive use of the qualified customer.'
        ], 400);
    }

    $discountCustomerName = trim($discountCustomerName);
    $discountIdNumber = trim($discountIdNumber);

} else {

    $discountCustomerName = null;
    $discountIdNumber = null;
}

// ==========================================
// PAYMENT VALIDATION
// ==========================================

if ($paymentMethod === 'qr') {

    if (
        !is_string($paymentReference) ||
        trim($paymentReference) === ''
    ) {
        respond([
            'success' => false,
            'message' => 'Enter the QR payment reference.'
        ], 400);
    }

    $paymentReference = trim($paymentReference);

    if (strlen($paymentReference) > 150) {
        respond([
            'success' => false,
            'message' => 'The payment reference is too long.'
        ], 400);
    }

} else {

    $paymentReference = null;
}

$cashReceived = null;

if ($paymentMethod === 'cash') {

    if (
        (!is_string($cashReceivedInput) &&
         !is_int($cashReceivedInput) &&
         !is_float($cashReceivedInput)) ||
        !is_numeric($cashReceivedInput) ||
        !is_finite((float) $cashReceivedInput) ||
        (float) $cashReceivedInput < 0
    ) {
        respond([
            'success' => false,
            'message' => 'Enter a valid amount of cash received.'
        ], 400);
    }

    $cashReceived = round((float) $cashReceivedInput, 2);

} elseif ($cashReceivedInput !== null) {

    respond([
        'success' => false,
        'message' => 'Cash received must not be provided for QR payments.'
    ], 400);
}

// ==========================================
// PROCESS ORDER
// ==========================================

try {

    // ======================================
    // GET PRODUCTS FROM DATABASE
    // ======================================

    $productStmt = $conn->prepare(
        "SELECT product_id, product_name, price
         FROM products
         WHERE product_id = ?
         AND availability = 'available'"
    );

    if (!$productStmt) {
        throw new RuntimeException('Unable to prepare product query.');
    }

    $validatedItems = [];

    foreach ($items as $item) {

        if (!is_array($item)) {
            respond([
                'success' => false,
                'message' => 'Invalid cart item.'
            ], 400);
        }

        $productId = filter_var(
            $item['id'] ?? null,
            FILTER_VALIDATE_INT
        );

        $quantity = filter_var(
            $item['quantity'] ?? null,
            FILTER_VALIDATE_INT
        );

        if (
            $productId === false ||
            $productId <= 0 ||
            $quantity === false ||
            $quantity <= 0 ||
            $quantity > 100
        ) {
            respond([
                'success' => false,
                'message' => 'A product or quantity is invalid.'
            ], 400);
        }

        $productStmt->bind_param('i', $productId);
        $productStmt->execute();

        $product = $productStmt
            ->get_result()
            ->fetch_assoc();

        if (!$product) {
            respond([
                'success' => false,
                'message' => 'A product is unavailable. Please refresh the menu.'
            ], 400);
        }

        $validatedItems[] = [
            'product_id' => (int) $product['product_id'],
            'product_name' => $product['product_name'],
            'quantity' => $quantity,
            'unit_price' => (float) $product['price']
        ];
    }

    $productStmt->close();

    // ======================================
    // CALCULATE SUBTOTAL
    // ======================================

    $subtotal = 0.00;

    foreach ($validatedItems as $item) {

        $subtotal += round(
            $item['unit_price'] * $item['quantity'],
            2
        );
    }

    $subtotal = round($subtotal, 2);

    // ======================================
    // CALCULATE PWD / SENIOR DISCOUNT
    // ======================================

    if ($discountType !== 'none') {

        $discountRate = (float) NOOK32_SC_PWD_DISCOUNT_RATE;

        if ($discountRate <= 0 || $discountRate > 1) {
            throw new RuntimeException('Invalid discount configuration.');
        }

        // Apply the configured discount directly to the subtotal.
        // VAT exemption is not calculated or deducted.
        $discountAmount = round($subtotal * $discountRate, 2);
        $vatExemptAmount = 0.00;
    }

    // ======================================
    // FINAL ORDER TOTAL
    // ======================================

    $finalTotal = round(
        $subtotal - $discountAmount - $vatExemptAmount,
        2
    );

    if ($finalTotal < 0) {
        $finalTotal = 0.00;
    }

    // ======================================
    // CHECK CASH AGAINST DISCOUNTED TOTAL
    // ======================================

    if (
        $paymentMethod === 'cash' &&
        $cashReceived < $finalTotal
    ) {
        respond([
            'success' => false,
            'message' => 'Cash received is less than the order total.',
            'subtotal' => number_format($subtotal, 2, '.', ''),
            'discount_amount' => number_format($discountAmount, 2, '.', ''),
            'vat_exempt_amount' => number_format($vatExemptAmount, 2, '.', ''),
            'total' => number_format($finalTotal, 2, '.', ''),
            'change' => '0.00'
        ], 400);
    }

    // ======================================
    // SAVE ORDER
    // ======================================

    $database = new Database();
    $orderManager = new OrderManager($database);

    $userId = (int) $_SESSION['user_id'];

    if ($paymentMethod === 'cash') {

        $orderId = $orderManager->saveOrder(
            $userId,
            $validatedItems,
            'cash',
            $discountAmount,
            null,
            'pending',
            $cashReceived,
            true,
            $discountType,
            $discountCustomerName,
            $discountIdNumber,
            $vatExemptAmount
        );

        $change = round(
            $cashReceived - $finalTotal,
            2
        );

        respond([
            'success' => true,
            'message' => 'Cash payment recorded successfully.',
            'order_id' => $orderId,
            'payment_status' => 'paid',
            'subtotal' => number_format($subtotal, 2, '.', ''),
            'discount_type' => $discountType,
            'discount_amount' => number_format($discountAmount, 2, '.', ''),
            'vat_exempt_amount' => number_format($vatExemptAmount, 2, '.', ''),
            'total' => number_format($finalTotal, 2, '.', ''),
            'cash_received' => number_format($cashReceived, 2, '.', ''),
            'change' => number_format($change, 2, '.', '')
        ]);
    }

    // ======================================
    // QR PAYMENT - PENDING VERIFICATION
    // ======================================

    $orderId = $orderManager->saveOrder(
        $userId,
        $validatedItems,
        'qr',
        $discountAmount,
        $paymentReference,
        'pending',
        null,
        false,
        $discountType,
        $discountCustomerName,
        $discountIdNumber,
        $vatExemptAmount
    );

    respond([
        'success' => true,
        'message' => 'QR order saved. Verify the payment before marking it paid.',
        'order_id' => $orderId,
        'payment_status' => 'pending',
        'subtotal' => number_format($subtotal, 2, '.', ''),
        'discount_type' => $discountType,
        'discount_amount' => number_format($discountAmount, 2, '.', ''),
        'vat_exempt_amount' => number_format($vatExemptAmount, 2, '.', ''),
        'total' => number_format($finalTotal, 2, '.', '')
    ]);

} catch (InvalidArgumentException $e) {

    respond([
        'success' => false,
        'message' => $e->getMessage()
    ], 400);

} catch (Throwable $e) {

    error_log(
        'Nook32 checkout error: ' .
        $e->getMessage() .
        ' in ' .
        $e->getFile() .
        ' on line ' .
        $e->getLine()
    );

    respond([
        'success' => false,
        'message' =>
            'DEBUG ERROR: ' . $e->getMessage() .
            ' | FILE: ' . basename($e->getFile()) .
            ' | LINE: ' . $e->getLine()
    ], 500);
}