
<?php

require_once __DIR__ . '/Database.php';

class OrderManager
{
    private mysqli $connection;

    public function __construct(Database $database)
    {
        $this->connection = $database->getConnection();
    }

    public function saveOrder(
        ?int $userId,
        array $items,
        string $paymentMethod,
        float $discountAmount = 0.00,
        ?string $paymentReference = null,
        string $paymentStatus = 'pending'
    ): int {
        if (empty($items)) {
            throw new InvalidArgumentException(
                "The cart cannot be empty."
            );
        }

        if (!in_array($paymentMethod, ['cash', 'qr'], true)) {
            throw new InvalidArgumentException(
                "Invalid payment method."
            );
        }

        if (!in_array($paymentStatus, ['pending', 'paid', 'failed'], true)) {
            throw new InvalidArgumentException(
                "Invalid payment status."
            );
        }

        $subtotal = 0.00;

        foreach ($items as $item) {
            if (
                !isset(
                    $item['product_id'],
                    $item['product_name'],
                    $item['quantity'],
                    $item['unit_price']
                )
            ) {
                throw new InvalidArgumentException(
                    "An order item is missing required information."
                );
            }

            $quantity = filter_var(
                $item['quantity'],
                FILTER_VALIDATE_INT
            );

            $price = filter_var(
                $item['unit_price'],
                FILTER_VALIDATE_FLOAT
            );

            if (
                $quantity === false ||
                $quantity <= 0 ||
                $price === false ||
                $price < 0
            ) {
                throw new InvalidArgumentException(
                    "Invalid product quantity or price."
                );
            }

            $subtotal += round($price * $quantity, 2);
        }

        $subtotal = round($subtotal, 2);
        $discountAmount = round($discountAmount, 2);

        if (
            $discountAmount < 0 ||
            $discountAmount > $subtotal
        ) {
            throw new InvalidArgumentException(
                "Invalid discount amount."
            );
        }

        $totalAmount = round(
            $subtotal - $discountAmount,
            2
        );

        if ($paymentMethod === 'cash' && $paymentReference !== null) {
            throw new InvalidArgumentException(
                "Cash payments should not have a QR reference."
            );
        }

        if (
            $paymentMethod === 'qr' &&
            $paymentStatus === 'paid' &&
            trim((string) $paymentReference) === ''
        ) {
            throw new InvalidArgumentException(
                "A payment reference is required for a recorded QR payment."
            );
        }

        $this->connection->begin_transaction();

        try {
            $orderSql = "INSERT INTO orders
                (user_id, subtotal, discount_amount, total_amount,
                 payment_method, payment_reference, payment_status)
                VALUES (?, ?, ?, ?, ?, ?, ?)";

            $orderStmt = $this->connection->prepare($orderSql);

            $orderStmt->bind_param(
                "idddsss",
                $userId,
                $subtotal,
                $discountAmount,
                $totalAmount,
                $paymentMethod,
                $paymentReference,
                $paymentStatus
            );

            $orderStmt->execute();

            $orderId = (int) $this->connection->insert_id;

            $itemSql = "INSERT INTO order_items
                (order_id, product_id, product_name,
                 quantity, unit_price, item_total)
                VALUES (?, ?, ?, ?, ?, ?)";

            $itemStmt = $this->connection->prepare($itemSql);

            foreach ($items as $item) {
                $productId = filter_var(
                    $item['product_id'],
                    FILTER_VALIDATE_INT
                );

                if ($productId === false || $productId <= 0) {
                    throw new InvalidArgumentException(
                        "Invalid product ID."
                    );
                }

                $productName = trim((string) $item['product_name']);
                $quantity = (int) $item['quantity'];
                $unitPrice = round((float) $item['unit_price'], 2);
                $itemTotal = round($unitPrice * $quantity, 2);

                if ($productName === '' || strlen($productName) > 150) {
                    throw new InvalidArgumentException(
                        "Invalid product name."
                    );
                }

                $itemStmt->bind_param(
                    "iisidd",
                    $orderId,
                    $productId,
                    $productName,
                    $quantity,
                    $unitPrice,
                    $itemTotal
                );

                $itemStmt->execute();
            }

            $this->connection->commit();

            return $orderId;

        } catch (Throwable $e) {
            $this->connection->rollback();
            throw $e;
        }
    }
}
