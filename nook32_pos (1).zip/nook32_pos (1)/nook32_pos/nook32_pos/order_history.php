<?php

require_once __DIR__ . '/auth.php';

requireLogin();

// Allow both admin and cashier to view order history.
$userRole = $_SESSION['role'] ?? '';

if (!in_array($userRole, ['admin', 'cashier'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

require_once __DIR__ . '/config/database.php';

// Default to today's date.
// If the admin selects another date, use that date instead.
$selectedDate = $_GET['date'] ?? date('Y-m-d');

// Validate the date format.
$dateObject = DateTime::createFromFormat('!Y-m-d', $selectedDate);

if (!$dateObject || $dateObject->format('Y-m-d') !== $selectedDate) {
    $selectedDate = date('Y-m-d');
}

// Get orders for the selected date.
// The date filter does not delete or change any orders.
$sql = "
    SELECT
        o.order_id,
        o.order_date,
        o.subtotal,
        o.discount_amount,
        o.total_amount,
        o.payment_method,
        o.payment_reference,
        o.payment_status,
        o.cash_received,
        o.change_amount,

        GROUP_CONCAT(
            CONCAT(oi.product_name, ' × ', oi.quantity)
            ORDER BY oi.order_item_id
            SEPARATOR ', '
        ) AS item_names

    FROM orders o

    LEFT JOIN order_items oi
        ON o.order_id = oi.order_id

    WHERE o.order_date >= ?
      AND o.order_date < DATE_ADD(?, INTERVAL 1 DAY)

    GROUP BY
        o.order_id,
        o.order_date,
        o.subtotal,
        o.discount_amount,
        o.total_amount,
        o.payment_method,
        o.payment_reference,
        o.payment_status,
        o.cash_received,
        o.change_amount

    ORDER BY o.order_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $selectedDate, $selectedDate);
$stmt->execute();

$result = $stmt->get_result();

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

$message = $_GET['message'] ?? '';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Order History | Nook32 Coffee</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        .container {
            max-width: 1500px;
            margin: auto;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0 0 8px;
            color: #39271f;
        }

        header p {
            margin: 0;
            color: #654633;
        }

        .nav-links {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .nav-links a {
            display: inline-block;
            padding: 10px 16px;
            border: 1px solid #dfcbb7;
            border-radius: 25px;
            background: #fff8ed;
            color: #39271f;
            text-decoration: none;
            font-weight: bold;
        }

        .nav-links a:hover {
            background: #dfcbb7;
        }

        .card {
            padding: 24px;
            background: #fffdf9;
            border: 1px solid #dfcbb7;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(57, 39, 31, 0.06);
        }

        h2 {
            margin-top: 0;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 1250px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 14px 12px;
            border-bottom: 1px solid #eadfd2;
            text-align: left;
            vertical-align: middle;
            font-size: 14px;
        }

        th {
            background: #f7f1e8;
            color: #39271f;
            white-space: nowrap;
        }

        tbody tr:hover {
            background: #fff8ed;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .status.paid {
            background: #dcefdc;
            color: #24632b;
        }

        .status.pending {
            background: #fff0c2;
            color: #795b00;
        }

        .status.failed {
            background: #f8d7da;
            color: #842029;
        }

        .verify-form {
            margin: 0;
        }

        .verify-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            background: #654633;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .verify-btn:hover {
            background: #39271f;
        }

        .message {
            margin-bottom: 20px;
            padding: 12px 16px;
            border-radius: 8px;
            background: #fff8ed;
            border: 1px solid #dfcbb7;
        }

        .notice {
            margin: 15px 0;
            color: #654633;
            font-size: 14px;
        }

        .empty {
            padding: 25px;
            text-align: center;
            color: #654633;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            .card {
                padding: 15px;
            }
        }

         .date-filter-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;

    margin: 22px 0;
    padding: 22px;

    background: #fffdf9;
    border: 1px solid #dfcbb7;
    border-radius: 14px;

    box-shadow: 0 4px 12px rgba(57, 39, 31, 0.05);
}

.date-filter-heading {
    display: flex;
    align-items: center;
    gap: 12px;
}

.date-filter-icon {
    display: flex;
    align-items: center;
    justify-content: center;

    width: 46px;
    height: 46px;

    background: #f7f1e8;
    border-radius: 12px;

    font-size: 22px;
}

.date-filter-heading h3 {
    margin: 0 0 5px;
    color: #39271f;
    font-size: 17px;
}

.date-filter-heading p {
    margin: 0;
    color: #8a7565;
    font-size: 13px;
}

.date-filter-form {
    display: flex;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 10px;
}

.date-input-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.date-input-group label {
    color: #654633;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.date-input-group input {
    min-height: 42px;
    padding: 10px 12px;

    border: 1px solid #dfcbb7;
    border-radius: 8px;

    background: #fff;
    color: #39271f;

    font-family: Arial, sans-serif;
    font-size: 14px;
}

.date-input-group input:focus {
    outline: none;
    border-color: #654633;
    box-shadow: 0 0 0 3px rgba(101, 70, 51, 0.12);
}

.filter-btn,
.today-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    min-height: 42px;
    padding: 10px 18px;

    border-radius: 8px;
    font-size: 14px;
    font-weight: bold;
    text-decoration: none;

    cursor: pointer;
    transition: 0.2s ease;
}

.filter-btn {
    border: 1px solid #39271f;
    background: #39271f;
    color: #fffdf9;
}

.filter-btn:hover {
    background: #654633;
    border-color: #654633;
}

.today-btn {
    border: 1px solid #dfcbb7;
    background: #f7f1e8;
    color: #39271f;
}

.today-btn:hover {
    background: #dfcbb7;
}

@media (max-width: 700px) {
    .date-filter-card {
        align-items: stretch;
    }

    .date-filter-form {
        width: 100%;
    }

    .date-input-group {
        width: 100%;
    }

    .date-input-group input {
        width: 100%;
    }

    .filter-btn,
    .today-btn {
        flex: 1;
    }
}
    </style>
</head>

<body>
<div class="container">

    <header>
        <div>
            <h1>NOOK32 COFFEE</h1>
            <p>Good coffee, cozy moments.</p>
        </div>

        <nav class="nav-links">
    <a href="index.php">POS Menu</a>
    <a href="order_history.php">Order History</a>

    <?php if ($userRole === 'admin'): ?>
        <a href="dashboard.php">Dashboard</a>
    <?php endif; ?>

    <a href="logout.php">Logout</a>
</nav>
    </header>

    <div class="card">
        <h2>Order History</h2>

        <?php if ($message === 'verified'): ?>
            <div class="message">
                QR payment marked as paid successfully.
            </div>
        <?php elseif ($message === 'unchanged'): ?>
            <div class="message">
                This order could not be updated. It may already be paid
                or may not be a pending QR order.
            </div>
        <?php elseif ($message === 'invalid'): ?>
            <div class="message">
                Invalid order ID.
            </div>
        <?php elseif ($message === 'error'): ?>
            <div class="message">
                An error occurred while updating the payment.
                Please try again.
            </div>
        <?php endif; ?>

        <p class="notice">
            Before verifying a QR payment, confirm that the payment
            was actually received.
        </p>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date and Time</th>
                        <th>Items Ordered</th>
                        <th>Subtotal</th>
                        <th>Discount</th>
                        <th>Total</th>
                        <th>Payment</th>
                        <th>Payment Reference</th>
                        <th>Cash Received</th>
                        <th>Change</th>
                        <th>Status</th>
                        <th>Action</th>
                        <div class="date-filter-card">
    <div class="date-filter-heading">
        <span class="date-filter-icon">📅</span>

        <div>
            <h3>Filter Order History</h3>
            <p>Choose a date to view your orders.</p>
        </div>
    </div>

    <form method="GET" class="date-filter-form">
        <div class="date-input-group">
            <label for="date">Order Date</label>

            <input
                type="date"
                id="date"
                name="date"
                value="<?= e($selectedDate) ?>"
                required
            >
        </div>

        <button type="submit" class="filter-btn">
            View Orders
        </button>

        <a href="order_history.php" class="today-btn">
            Today
        </a>
    </form>
</div>
                    </tr>
                </thead>

                <tbody>
                <?php if ($result->num_rows > 0): ?>

                    <?php while ($order = $result->fetch_assoc()): ?>
                        <tr>
                            <td>
                                #<?= e($order['order_id']) ?>
                            </td>

                            <td>
                                <?= e(date(
                                    'M d, Y h:i A',
                                    strtotime($order['order_date'])
                                )) ?>
                            </td>

                            <td>
                                <?= e($order['item_names'] ?? 'No items') ?>
                            </td>

                            <td>
                                ₱<?= number_format(
                                    (float) $order['subtotal'],
                                    2
                                ) ?>
                            </td>

                            <td>
                                ₱<?= number_format(
                                    (float) $order['discount_amount'],
                                    2
                                ) ?>
                            </td>

                            <td>
                                <strong>
                                    ₱<?= number_format(
                                        (float) $order['total_amount'],
                                        2
                                    ) ?>
                                </strong>
                            </td>

                            <td>
                                <?= e(strtoupper(
                                    $order['payment_method']
                                )) ?>
                            </td>

                            <td>
                                <?php if (
                                    $order['payment_method'] === 'qr'
                                ): ?>
                                    <?= e(
                                        $order['payment_reference']
                                        ?: 'No reference'
                                    ) ?>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if (
                                    $order['cash_received'] !== null
                                ): ?>
                                    ₱<?= number_format(
                                        (float) $order['cash_received'],
                                        2
                                    ) ?>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if (
                                    $order['change_amount'] !== null
                                ): ?>
                                    ₱<?= number_format(
                                        (float) $order['change_amount'],
                                        2
                                    ) ?>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>

                            <td>
                                <span class="status <?= e(
                                    $order['payment_status']
                                ) ?>">
                                    <?= e(
                                        strtoupper(
                                            $order['payment_status']
                                        )
                                    ) ?>
                                </span>
                            </td>

                            <td>
                                <?php if (
                                    $order['payment_method'] === 'qr'
                                    && $order['payment_status'] === 'pending'
                                ): ?>
                                    <form
                                        class="verify-form"
                                        method="POST"
                                        action="verify_qr_payment.php"
                                        onsubmit="return confirm(
                                            'Have you confirmed that this QR payment was received?'
                                        );"
                                    >
                                       <input
                                            type="hidden"
                                            name="order_id"
                                            value="<?= e($order['order_id']) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($_SESSION['csrf_token']) ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="verify-btn"
                                        >
                                            Verify Payment
                                        </button>
                                    </form>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>

                <?php else: ?>
                    <tr>
                        <td colspan="12" class="empty">
                            No orders found.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>