<?php
session_start();

require_once __DIR__ . '/auth.php';
requireLogin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Nook32 Coffee | Checkout</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f7f1e8;
    color: #39271f;
}

header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: #39271f;
    color: #fffdf9;
    padding: 22px 6%;
    box-shadow: 0 3px 12px rgba(57,39,31,.15);
}

header h1 {
    margin: 0;
}

header p {
    color: #dfcbb7;
    margin-bottom: 0;
}

main {
    max-width: 850px;
    margin: 35px auto;
    padding: 0 20px;
}

.back-link {
    display: inline-block;
    margin-bottom: 20px;
    color: #654633;
    text-decoration: none;
    font-weight: bold;
}

.checkout-card {
    background: #fffdf9;
    border: 1px solid #e8dbcd;
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 20px;
}

.checkout-card h2 {
    margin-top: 0;
}

.order-item {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    padding: 15px 0;
    border-bottom: 1px solid #e8dbcd;
}

.order-item small {
    display: block;
    color: #806c5d;
    margin-top: 5px;
}

.total-line {
    display: flex;
    justify-content: space-between;
    margin-top: 18px;
    font-size: 20px;
    font-weight: bold;
}

label {
    display: block;
    font-weight: bold;
    margin: 18px 0 8px;
}

input, select {
    width: 100%;
    padding: 13px;
    border: 1px solid #d8c6b4;
    border-radius: 9px;
    background: #fffdf9;
    font-size: 15px;
}

.help {
    display: block;
    color: #806c5d;
    margin-top: 7px;
    font-size: 13px;
}

.change-preview {
    background: #f3e9dd;
    border-radius: 9px;
    padding: 13px;
    font-weight: bold;
}

.confirm-button {
    width: 100%;
    margin-top: 22px;
    padding: 15px;
    border: none;
    border-radius: 30px;
    background: #654633;
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

.confirm-button:hover {
    background: #493021;
}

.confirm-button:disabled {
    opacity: .6;
    cursor: not-allowed;
}

.message {
    margin-top: 15px;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.error {
    color: #a12d25;
}

.success {
    color: #28643c;
}

.empty {
    text-align: center;
    padding: 25px;
    color: #806c5d;
}

@media(max-width:600px) {
    header {
        padding: 18px 5%;
    }

    .checkout-card {
        padding: 18px;
    }
}
/* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

@media (max-width: 600px) {
    .footer-content {
        flex-direction: column;
        gap: 20px;
    }
}
</style>
</head>

<body>

<header>
    <h1>NOOK32 COFFEE</h1>
    <p>Good coffee, cozy moments.</p>
</header>

<main>

    <a href="index.php" class="back-link">
        ← Back to Menu
    </a>

    <h2>Checkout</h2>
    <p>Review your order before confirming payment.</p>

    <section class="checkout-card">

        <h2>Your Order</h2>

        <div id="orderItems"></div>

        <div class="total-line">
            <span>Subtotal</span>
            <span id="subtotal">₱0.00</span>
        </div>

        <div class="total-line">
            <span>Total</span>
            <span id="total">₱0.00</span>
        </div>

    </section>

    <section class="checkout-card">

        <h2>Payment Details</h2>

        <label for="paymentMethod">Payment Method</label>

        <select id="paymentMethod">
            <option value="cash">Cash</option>
            <option value="qr">QR Payment</option>
        </select>

        <div id="cashFields">

            <label for="cashReceived">Cash Received (₱)</label>

            <input
                type="number"
                id="cashReceived"
                min="0"
                step="0.01"
                placeholder="Enter amount received"
            >

            <small class="help">
                Enter the cash physically received from the customer.
            </small>

            <p class="change-preview" id="changePreview">
                Change: ₱0.00
            </p>

        </div>

        <div id="qrFields" style="display:none;">

            <label for="paymentReference">
                QR Payment Reference Number
            </label>

            <input
                type="text"
                id="paymentReference"
                maxlength="150"
                placeholder="Enter payment reference"
            >

            <small class="help">
                QR payments remain pending until verified.
            </small>

        </div>

        <button
            type="button"
            class="confirm-button"
            id="confirmButton"
            onclick="checkoutOrder()"
        >
            Confirm Order
        </button>

        <p id="message" class="message" role="status"></p>

    </section>

</main>
<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h2>NOOK32 COFFEE ☕</h2>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">
            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <!-- Facebook -->
                <a href="https://facebook.com/nook32coffee"
                   target="_blank"
                   aria-label="Facebook">
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <!-- Instagram -->
                <a href="https://instagram.com/nook32coffee"
                   target="_blank"
                   aria-label="Instagram">
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- TikTok -->
                <a href="https://tiktok.com/@nook32coffee"
                   target="_blank"
                   aria-label="TikTok">
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 0 6.2 6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.</p>
    </div>

</footer>

<script>

let cart = [];

try {
    cart = JSON.parse(sessionStorage.getItem('nook32_cart')) || [];
} catch (error) {
    cart = [];
}

const paymentMethod = document.getElementById('paymentMethod');
const cashReceived = document.getElementById('cashReceived');
const paymentReference = document.getElementById('paymentReference');
const cashFields = document.getElementById('cashFields');
const qrFields = document.getElementById('qrFields');
const changePreview = document.getElementById('changePreview');
const confirmButton = document.getElementById('confirmButton');
const message = document.getElementById('message');

function getTotal() {
    return Math.round(
        cart.reduce((sum, item) => {
            return sum + Number(item.price) * Number(item.quantity);
        }, 0) * 100
    ) / 100;
}

function renderOrder() {

    const container = document.getElementById('orderItems');

    container.replaceChildren();

    if (cart.length === 0) {
        container.innerHTML =
            '<p class="empty">Your cart is empty. Please return to the menu.</p>';

        confirmButton.disabled = true;
        return;
    }

    confirmButton.disabled = false;

    cart.forEach(item => {

        const row = document.createElement('div');
        row.className = 'order-item';

        const info = document.createElement('div');

        const name = document.createElement('strong');
        name.textContent = item.name;

        const details = document.createElement('small');
        details.textContent =
            'Quantity: ' + item.quantity +
            ' × ₱' + Number(item.price).toFixed(2);

        info.append(name, details);

        const amount = document.createElement('strong');

        amount.textContent =
            '₱' + (Number(item.price) * Number(item.quantity)).toFixed(2);

        row.append(info, amount);

        container.appendChild(row);

    });

    document.getElementById('subtotal').textContent =
        '₱' + getTotal().toFixed(2);

    document.getElementById('total').textContent =
        '₱' + getTotal().toFixed(2);

    updatePaymentFields();
}

function updatePaymentFields() {

    const isCash = paymentMethod.value === 'cash';

    cashFields.style.display = isCash ? 'block' : 'none';
    qrFields.style.display = isCash ? 'none' : 'block';

    cashReceived.required = isCash;
    paymentReference.required = !isCash;

    confirmButton.textContent = isCash
        ? 'Confirm Cash Payment & Save Order'
        : 'Save QR Order as Pending';

    updateChange();
}

function updateChange() {

    const total = getTotal();
    const received = Number(cashReceived.value);

    if (
        cart.length === 0 ||
        cashReceived.value === '' ||
        !Number.isFinite(received) ||
        received < total
    ) {
        changePreview.textContent =
            'Enter enough cash to cover ₱' + total.toFixed(2);
        return;
    }

    changePreview.textContent =
        'Change: ₱' + (received - total).toFixed(2);
}

async function checkoutOrder() {

    if (cart.length === 0) {
        message.className = 'message error';
        message.textContent = 'Your cart is empty.';
        return;
    }

    const method = paymentMethod.value;
    const total = getTotal();

    if (method === 'cash') {

        const received = Number(cashReceived.value);

        if (
            cashReceived.value === '' ||
            !Number.isFinite(received) ||
            received < total
        ) {
            message.className = 'message error';
            message.textContent =
                'Please enter enough cash to cover the order total.';
            return;
        }

        if (!confirm(
            'Confirm that ₱' + received.toFixed(2) +
            ' cash has been received?'
        )) {
            return;
        }

    } else if (!paymentReference.value.trim()) {

        message.className = 'message error';
        message.textContent =
            'Please enter the QR payment reference number.';
        return;

    }

    confirmButton.disabled = true;
    message.className = 'message';
    message.textContent = 'Processing your order...';

    try {

        const response = await fetch('checkout.php', {

            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({

                items: cart.map(item => ({
                    id: item.id,
                    quantity: item.quantity
                })),

                payment_method: method,

                payment_reference: method === 'qr'
                    ? paymentReference.value.trim()
                    : null,

                cash_received: method === 'cash'
                    ? cashReceived.value
                    : null

            })

        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || 'Unable to process order.'
            );
        }

        sessionStorage.removeItem('nook32_cart');
        cart = [];

        if (result.payment_status === 'paid') {

            message.className = 'message success';

            message.textContent =
                'Order #' + result.order_id +
                ' successfully paid! Total: ₱' + result.total +
                '. Change: ₱' + result.change;

        } else {

            message.className = 'message success';

            message.textContent =
                'Order #' + result.order_id +
                ' saved successfully. QR payment is pending verification.';

        }

        renderOrder();

        paymentMethod.disabled = true;
        cashReceived.disabled = true;
        paymentReference.disabled = true;

    } catch (error) {

        message.className = 'message error';
        message.textContent = error.message;

        confirmButton.disabled = false;

    }
}

paymentMethod.addEventListener('change', updatePaymentFields);
cashReceived.addEventListener('input', updateChange);

renderOrder();

</script>

</body>
</html>
