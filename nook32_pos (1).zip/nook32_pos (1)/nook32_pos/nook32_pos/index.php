<?php

session_start();

require_once __DIR__ . '/auth.php';
requireLogin();

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/config/database.php';

$sql = "SELECT
            p.product_id,
            p.product_name,
            p.price,
            p.image,
            c.category_name
        FROM products p
        LEFT JOIN categories c
            ON p.category_id = c.category_id
        WHERE p.availability = 'available'
        ORDER BY c.category_id, p.product_name";

$result = $conn->query($sql);

$categories = [];
$products = [];

while ($row = $result->fetch_assoc()) {
    $products[] = $row;

    if (!empty($row['category_name'])) {
        $categories[$row['category_name']] = true;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Nook32 Coffee | POS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f7f1e8;
    color: #39271f;
    padding-bottom: 110px;
}

/* STICKY HEADER */

header {
    position: sticky;
    top: 0;
    z-index: 1000;

    background: #39271f;
    color: #fff8ed;

    padding: 20px 6%;

    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;

    box-shadow: 0 3px 12px rgba(0,0,0,0.15);
}

header h1 {
    margin: 0;
    font-size: 27px;
}

header p {
    margin: 7px 0 0;
    color: #dfcbb7;
}

.header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.badge {
    border: 1px solid #a98a70;
    border-radius: 25px;
    padding: 10px 16px;
    white-space: nowrap;
}

.logout-btn {
    display: inline-block;
    padding: 10px 16px;
    border: 1px solid #dfcbb7;
    border-radius: 25px;
    background: #fff8ed;
    color: #39271f;
    text-decoration: none;
    font-size: 14px;
    font-weight: bold;
}

.logout-btn:hover {
    background: #dfcbb7;
}

/* MAIN CONTENT */

main {
    max-width: 1200px;
    margin: 35px auto;
    padding: 0 20px;
}

.intro {
    margin-bottom: 25px;
}

.intro h2 {
    font-size: 30px;
    margin-bottom: 8px;
}

.intro p,
.cart-item-info small {
    color: #806c5d;
}

/* SEARCH AND CATEGORY */

.toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 25px;
}

.toolbar input,
.toolbar select {
    padding: 12px;
    border: 1px solid #d8c6b4;
    border-radius: 10px;
    background: #fffdf9;
    color: #38271f;
}

.toolbar input {
    flex: 1;
    min-width: 180px;
}

/* PRODUCT MENU */

.menu {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 18px;
}

.product,
.cart-panel {
    background: #fffdf9;
    border: 1px solid #e8dbcd;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 4px 14px rgba(57,39,31,0.04);
}

.product-image {
    width: 100%;
    height: 160px;
    object-fit: cover;
    border-radius: 12px;
    margin-bottom: 16px;
    background: #eee1d1;
}

.product-image-placeholder {
    height: 160px;
    display: grid;
    place-items: center;
    font-size: 42px;
    background: #eee1d1;
    border-radius: 12px;
    margin-bottom: 16px;
}

.product small {
    color: #8c6d54;
}

.product h3 {
    margin: 10px 0;
    min-height: 40px;
}

.product {
    transition: all 0.25s ease;
    cursor: pointer;
}

.product:hover {
    border-color: #654633;
    background: #f3e9dd;
    box-shadow: 0 5px 16px rgba(57, 39, 31, 0.12);
    transform: translateY(-3px);
}

.price {
    font-size: 20px;
    font-weight: bold;
    margin: 14px 0;
}

.add-button {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 9px;
    background: #654633;
    color: white;
    cursor: pointer;
    font-size: 15px;
}

.add-button:hover {
    background: #493021;
}

/* CURRENT ORDER */

.cart-panel {
    margin-top: 35px;
    padding: 24px;
}

.cart-empty {
    padding: 15px;
    color: #806c5d;
    text-align: center;
}

.cart-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    padding: 15px 0;
    border-bottom: 1px solid #e8dbcd;
}

.cart-item-info {
    flex: 1;
    min-width: 150px;
}

.cart-item-info small {
    display: block;
    margin-top: 6px;
}

.cart-controls {
    display: flex;
    align-items: center;
    gap: 8px;
}

.cart-controls button {
    min-width: 32px;
    min-height: 32px;
    border: none;
    border-radius: 7px;
    background: #eee1d1;
    color: #38271f;
    cursor: pointer;
    font-size: 17px;
}

.cart-controls .remove-button {
    padding: 6px 10px;
    background: #f5e3df;
    color: #8b3328;
    font-size: 13px;
}

.cart-summary {
    margin-top: 20px;
}

.summary-line {
    display: flex;
    justify-content: space-between;
    gap: 12px;
}

.cart-total {
    padding-top: 12px;
    border-top: 1px solid #e8dbcd;
    font-size: 20px;
}

.clear-button {
    width: 100%;
    margin-top: 12px;
    padding: 12px;
    border: 1px solid #654633;
    border-radius: 9px;
    background: transparent;
    color: #654633;
    cursor: pointer;
    font-size: 15px;
}

.clear-button:hover {
    background: #f3e9dd;
}

/* FIXED BOTTOM CART BAR */

.bottom-cart {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;

    background: #fffdf9;
    border-top: 1px solid #e8dbcd;

    padding: 16px 5%;

    display: none;
    align-items: center;
    justify-content: space-between;
    gap: 20px;

    z-index: 999;

    box-shadow: 0 -4px 15px rgba(57,39,31,0.10);
}

.bottom-cart.show {
    display: flex;
}

.bottom-cart-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.bottom-cart-info small {
    color: #806c5d;
    font-weight: bold;
    font-size: 13px;
}

.bottom-cart-info strong {
    font-size: 27px;
    color: #654633;
}

.order-now-button {
    border: none;
    border-radius: 30px;
    background: #654633;
    color: white;

    padding: 16px 35px;

    font-size: 16px;
    font-weight: bold;

    cursor: pointer;
    white-space: nowrap;
}

.order-now-button:hover {
    background: #493021;
}

.order-now-button:disabled {
    opacity: .6;
    cursor: not-allowed;
}

/* FOOTER */

footer {
    text-align: center;
    color: #806c5d;
    padding: 35px 15px;
}

/* MOBILE */

@media (max-width: 600px) {

    header {
        padding: 16px 5%;
        align-items: flex-start;
        flex-direction: column;
    }

    header h1 {
        font-size: 23px;
    }

    .intro h2 {
        font-size: 25px;
    }

    .cart-controls {
        flex-wrap: wrap;
    }

    .bottom-cart {
        padding: 13px 16px;
        gap: 10px;
    }

    .bottom-cart-info strong {
        font-size: 22px;
    }

    .order-now-button {
        padding: 14px 20px;
        font-size: 14px;
    }
}
/* NAVIGATION BAR */

.navbar {
    position: sticky;
    top: 85px;
    z-index: 999;
    background: #f7f1e8;
    padding: 10px 5%;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    border-bottom: 1px solid #e8dbcd;
}

.navbar a {
    display: inline-block;
    padding: 9px 18px;
    border: 1.5px solid #b18e70;
    border-radius: 30px;
    color: #39271f;
    text-decoration: none;
    font-size: 14px;
    transition: 0.2s;
}

.navbar a:hover,
.navbar a.active {
    background: #654633;
    color: white;
    border-color: #654633;
}
/* FOOTER */

.site-footer {
    background: #39271f;
    color: #fffdf9;
    padding: 40px 7% 15px;
    margin-top: 50px;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 35px;
    max-width: 1200px;
    margin: auto;
}

.footer-content h2 {
    margin: 0 0 10px;
    font-size: 22px;
}

.footer-content h3 {
    font-size: 15px;
    margin-bottom: 15px;
    color: #d7b998;
}

.footer-content p {
    color: #dfcbb7;
    font-size: 14px;
}

.social-icons {
    display: flex;
    gap: 12px;
}

.social-icons a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #fffdf9;
    color: #654633;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: 0.3s;
}

.social-icons a:hover {
    background: #d7b998;
    transform: translateY(-4px);
}

.social-icons svg {
    width: 21px;
    height: 21px;
    fill: currentColor;
    stroke: currentColor;
    stroke-width: 1.8;
}

.footer-bottom {
    border-top: 1px solid #765b48;
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
}

.footer-bottom p {
    font-size: 12px;
    color: #cbb8a7;
}

@media (max-width: 600px) {
    .footer-content {
        flex-direction: column;
        gap: 20px;
    }
}

</style>

</head>

<body>

<header>

    <div>
        <h1>NOOK32 COFFEE</h1>
        <p>Good coffee, cozy moments.</p>
    </div>

    <div class="header-actions">

        <div class="badge">
            <?= htmlspecialchars(
                ucfirst($_SESSION['role'] ?? 'User'),
                ENT_QUOTES,
                'UTF-8'
            ) ?>
        </div>

        <div class="badge">POS MENU</div>

        <a href="logout.php" class="logout-btn">Logout</a>

    </div>

</header>
<nav class="navbar">

    <a href="index.php" class="active">POS Menu</a>
    <a href="order_history.php">Order History</a>

    <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>

        <a href="dashboard.php">Dashboard</a>
        <a href="inventory.php">Inventory</a>
        <a href="manage_users.php">Manage Users</a>

    <?php endif; ?>

</nav>
<main>

    <section class="intro">

        <h2>Our Coffee Menu ☕</h2>

        <p>Select a category or search for your favorite drink.</p>

    </section>

    <!-- SEARCH AND CATEGORY -->

    <div class="toolbar">

        <input
            type="search"
            id="search"
            placeholder="Search coffee, frappe, pastry..."
            aria-label="Search products"
        >

        <select id="category" aria-label="Filter by category">

            <option value="">All Categories</option>

            <?php foreach (array_keys($categories) as $category): ?>

                <option value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>
                </option>

            <?php endforeach; ?>

        </select>

    </div>

    <!-- PRODUCT MENU -->

    <section class="menu" id="menu">

        <?php foreach ($products as $product): ?>

            <article
                class="product"
                data-name="<?= htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8') ?>"
                data-category="<?= htmlspecialchars($product['category_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
            >

                <?php if (!empty($product['image'])): ?>
    <img
        src="assets/images/products/<?= htmlspecialchars(
            basename($product['image']),
            ENT_QUOTES,
            'UTF-8'
        ) ?>"
        alt="<?= htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8') ?>"
        class="product-image"
        onerror="this.style.display='none'; this.nextElementSibling.style.display='grid';"
    >
    <div class="product-image-placeholder" style="display:none;">☕</div>
<?php else: ?>
    <div class="product-image-placeholder">☕</div>
<?php endif; ?>

                <small>
                    <?= htmlspecialchars($product['category_name'] ?? 'Other', ENT_QUOTES, 'UTF-8') ?>
                </small>

                <h3>
                    <?= htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8') ?>
                </h3>

                <div class="price">
                    ₱<?= number_format((float)$product['price'], 2) ?>
                </div>

                <button
                    class="add-button"
                    type="button"
                    onclick="addToCart(
                        <?= (int)$product['product_id'] ?>,
                        <?= htmlspecialchars(json_encode(
                            $product['product_name'],
                            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                        ), ENT_QUOTES, 'UTF-8') ?>,
                        <?= json_encode((float)$product['price']) ?>
                    )"
                >
                    + Add to Cart
                </button>

            </article>

        <?php endforeach; ?>

    </section>

    <?php if (count($products) === 0): ?>

        <p class="cart-empty">No available products were found.</p>

    <?php endif; ?>

    <!-- CURRENT ORDER -->

    <section class="cart-panel">

        <h2>Current Order</h2>

        <div id="cart">

            <p class="cart-empty">Your cart is empty.</p>

        </div>

        <div class="cart-summary">

            <p class="summary-line">
                <span>Subtotal</span>
                <strong id="subtotal">₱0.00</strong>
            </p>

            <h3 class="summary-line cart-total">
                <span>Total</span>
                <strong id="total">₱0.00</strong>
            </h3>

        </div>

        <button
            class="clear-button"
            type="button"
            onclick="clearCart()"
        >
            Clear Cart
        </button>

    </section>

</main>

<footer class="site-footer">

    <div class="footer-content">

        <div class="footer-brand">
            <h2>NOOK32 COFFEE ☕</h2>
            <p>Good coffee, cozy moments.</p>
        </div>

        <div class="footer-location">
            <h3>VISIT OUR SHOP</h3>
            <p>📍 No. 5 Mckinley St., Binmaley, Pangasinan</p>
        </div>

        <div class="footer-social">
            <h3>FOLLOW US</h3>

            <div class="social-icons">

                <!-- Facebook -->
                <a href="https://facebook.com/nook32coffee"
                   target="_blank"
                   aria-label="Facebook">
                    <svg viewBox="0 0 24 24">
                        <path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3V10H7.5v3h2.6v8z"/>
                    </svg>
                </a>

                <!-- Instagram -->
                <a href="https://instagram.com/nook32coffee"
                   target="_blank"
                   aria-label="Instagram">
                    <svg viewBox="0 0 24 24">
                        <rect x="3" y="3" width="18" height="18" rx="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- TikTok -->
                <a href="https://tiktok.com/@nook32coffee"
                   target="_blank"
                   aria-label="TikTok">
                    <svg viewBox="0 0 24 24">
                        <path d="M14 3v11.2a3.2 3.2 0 1 1-3-3.2V8a6.2 6.2 0 1 0 6.2 6.2V9.1c1.3 1 2.8 1.5 4.3 1.6V7.5c-2.4-.2-4.1-1.8-4.5-4.5z"/>
                    </svg>
                </a>

            </div>
        </div>

    </div>

    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Nook32 Coffee. All Rights Reserved.</p>
    </div>

</footer>

<!-- FIXED BOTTOM CART BAR -->

<div class="bottom-cart" id="bottomCart">

    <div class="bottom-cart-info">

        <small id="cartItemCount">0 ITEM(S) IN CART</small>

        <strong id="bottomCartTotal">₱0.00</strong>

    </div>

    <button
        type="button"
        class="order-now-button"
        onclick="goToCheckout()"
    >
        ORDER NOW
    </button>

</div>

<script>

// RESTORE CART WHEN RETURNING FROM CHECKOUT

let cart = [];

try {
    cart = JSON.parse(sessionStorage.getItem('nook32_cart')) || [];
} catch (error) {
    cart = [];
}

function saveCart() {
    sessionStorage.setItem('nook32_cart', JSON.stringify(cart));
}

function getCartTotal() {

    return Math.round(
        cart.reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
        ) * 100
    ) / 100;

}

function getTotalItems() {

    return cart.reduce(
        (sum, item) => sum + item.quantity,
        0
    );

}

// ADD PRODUCT

function addToCart(id, name, price) {

    id = Number(id);
    price = Number(price);

    if (!Number.isInteger(id) || !Number.isFinite(price) || price < 0) {
        return;
    }

    const item = cart.find(product => product.id === id);

    if (item) {

        item.quantity++;

    } else {

        cart.push({
            id: id,
            name: name,
            price: price,
            quantity: 1
        });

    }

    renderCart();

}

// CHANGE QUANTITY

function changeQuantity(id, amount) {

    const item = cart.find(product => product.id === id);

    if (!item) return;

    item.quantity += amount;

    if (item.quantity <= 0) {

        removeItem(id);
        return;

    }

    renderCart();

}

// REMOVE PRODUCT

function removeItem(id) {

    cart = cart.filter(product => product.id !== id);

    renderCart();

}

// CLEAR CART

function clearCart() {

    if (cart.length === 0) return;

    if (!confirm('Are you sure you want to clear your cart?')) {
        return;
    }

    cart = [];

    renderCart();

}

// DISPLAY CART

function renderCart() {

    const cartElement = document.getElementById('cart');

    const subtotal = getCartTotal();

    const totalItems = getTotalItems();

    cartElement.replaceChildren();

    if (cart.length === 0) {

        const emptyMessage = document.createElement('p');

        emptyMessage.className = 'cart-empty';
        emptyMessage.textContent = 'Your cart is empty.';

        cartElement.appendChild(emptyMessage);

    }

    cart.forEach(item => {

        const itemTotal = item.price * item.quantity;

        const row = document.createElement('div');
        row.className = 'cart-item';

        const info = document.createElement('div');
        info.className = 'cart-item-info';

        const name = document.createElement('strong');
        name.textContent = item.name;

        const details = document.createElement('small');

        details.textContent =
            '₱' + item.price.toFixed(2) +
            ' each · Amount: ₱' + itemTotal.toFixed(2);

        info.append(name, details);

        const controls = document.createElement('div');
        controls.className = 'cart-controls';

        const minus = document.createElement('button');

        minus.type = 'button';
        minus.textContent = '−';
        minus.setAttribute('aria-label', 'Decrease quantity');

        minus.onclick = () => changeQuantity(item.id, -1);

        const quantity = document.createElement('span');
        quantity.textContent = item.quantity;

        const plus = document.createElement('button');

        plus.type = 'button';
        plus.textContent = '+';
        plus.setAttribute('aria-label', 'Increase quantity');

        plus.onclick = () => changeQuantity(item.id, 1);

        const remove = document.createElement('button');

        remove.type = 'button';
        remove.className = 'remove-button';
        remove.textContent = 'Remove';

        remove.onclick = () => removeItem(item.id);

        controls.append(minus, quantity, plus, remove);

        row.append(info, controls);

        cartElement.appendChild(row);

    });

    document.getElementById('subtotal').textContent =
        '₱' + subtotal.toFixed(2);

    document.getElementById('total').textContent =
        '₱' + subtotal.toFixed(2);

    // UPDATE FIXED BOTTOM CART BAR

    const bottomCart = document.getElementById('bottomCart');

    if (totalItems > 0) {

        bottomCart.classList.add('show');

    } else {

        bottomCart.classList.remove('show');

    }

    document.getElementById('cartItemCount').textContent =
        totalItems + ' ITEM(S) IN CART';

    document.getElementById('bottomCartTotal').textContent =
        '₱' + subtotal.toFixed(2);

    // SAVE CART FOR CHECKOUT PAGE

    saveCart();

}

// GO TO SEPARATE CHECKOUT PAGE

function goToCheckout() {

    if (cart.length === 0) {

        alert('Please add products to your cart first.');

        return;

    }

    saveCart();

    window.location.href = 'checkout_page.php';

}

// SEARCH AND CATEGORY FILTER

function filterProducts() {

    const search = document.getElementById('search').value.toLowerCase();

    const category = document.getElementById('category').value;

    document.querySelectorAll('.product').forEach(product => {

        const matchesSearch =
            product.dataset.name.toLowerCase().includes(search);

        const matchesCategory =
            !category || product.dataset.category === category;

        product.style.display =
            matchesSearch && matchesCategory ? '' : 'none';

    });

}

document.getElementById('search')
    .addEventListener('input', filterProducts);

document.getElementById('category')
    .addEventListener('change', filterProducts);

// INITIALIZE CART

renderCart();

</script>

</body>
</html>
