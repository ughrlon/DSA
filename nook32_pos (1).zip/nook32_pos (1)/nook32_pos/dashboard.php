
<?php
require_once __DIR__ . '/auth.php';
requireRole('admin');

require_once __DIR__ . '/config/database.php';

// Today's paid sales and paid orders
$todaySql = "SELECT
                COALESCE(SUM(total_amount), 0) AS sales,
                COUNT(*) AS orders
             FROM orders
             WHERE payment_status = 'paid'
               AND order_date >= CURDATE()
               AND order_date < CURDATE() + INTERVAL 1 DAY";

$todayResult = $conn->query($todaySql);
$today = $todayResult->fetch_assoc();


// Today's payment status summary
$statusSql = "SELECT
                payment_status,
                COUNT(*) AS total_orders
              FROM orders
              WHERE order_date >= CURDATE()
                AND order_date < CURDATE() + INTERVAL 1 DAY
              GROUP BY payment_status";

$statusResult = $conn->query($statusSql);

$paymentSummary = [
    'paid' => 0,
    'pending' => 0,
    'failed' => 0
];

while ($status = $statusResult->fetch_assoc()) {
    if (array_key_exists($status['payment_status'], $paymentSummary)) {
        $paymentSummary[$status['payment_status']] =
            (int) $status['total_orders'];
    }
}


// Today's discounted orders and total discounts given
$discountSql = "SELECT
                    COUNT(
                        CASE
                            WHEN discount_type IN ('pwd', 'senior')
                            THEN 1
                        END
                    ) AS discounted_orders,

                    COALESCE(
                        SUM(
                            CASE
                                WHEN discount_type IN ('pwd', 'senior')
                                THEN discount_amount
                                ELSE 0
                            END
                        ), 0
                    ) AS total_discounts

                FROM orders
                WHERE payment_status = 'paid'
                  AND order_date >= CURDATE()
                  AND order_date < CURDATE() + INTERVAL 1 DAY";

$discountResult = $conn->query($discountSql);
$discountSummary = $discountResult->fetch_assoc();

$discountedOrders = (int) $discountSummary['discounted_orders'];
$totalDiscounts = (float) $discountSummary['total_discounts'];


// Today's top five best-selling products from paid orders
$bestSql = "SELECT
                oi.product_id,
                oi.product_name,
                SUM(oi.quantity) AS quantity_sold,
                SUM(oi.item_total) AS revenue
            FROM order_items oi
            INNER JOIN orders o
                ON o.order_id = oi.order_id
            WHERE o.payment_status = 'paid'
              AND o.order_date >= CURDATE()
              AND o.order_date < CURDATE() + INTERVAL 1 DAY
            GROUP BY oi.product_id, oi.product_name
            ORDER BY quantity_sold DESC, revenue DESC
            LIMIT 5";

$bestResult = $conn->query($bestSql);


// Escape output before displaying it in HTML
function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nook32 Coffee | Sales Dashboard</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #39271f;
        }

        header {
            background: #39271f;
            color: #fff8ed;
            padding: 24px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            margin: 0;
            font-size: 26px;
        }

        header p {
            color: #dfcbb7;
            margin-bottom: 0;
        }

        nav {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        nav a {
            color: #fff8ed;
            text-decoration: none;
            border: 1px solid #a98a70;
            border-radius: 9px;
            padding: 10px 14px;
        }

        nav a:hover,
        nav a.active {
            background: #654633;
        }

        main {
            max-width: 1200px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .dashboard-heading {
            text-align: center;
            margin-bottom: 28px;
        }

        .dashboard-heading h2 {
            margin: 0 0 18px;
        }

        .today-date {
            display: inline-block;
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 18px 30px;
            margin-bottom: 15px;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .today-label {
            display: block;
            color: #806c5d;
            font-size: 12px;
            font-weight: bold;
            letter-spacing: 2px;
            margin-bottom: 7px;
        }

        .today-date h3 {
            margin: 0;
            font-size: 25px;
        }

        .today-date p {
            margin: 7px 0 0;
            color: #806c5d;
        }

        .subtitle {
            color: #806c5d;
            line-height: 1.6;
        }

        /* Six dashboard cards */
        .stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin: 25px 0 35px;
        }

        .stat-card,
        .panel {
            background: #fffdf9;
            border: 1px solid #e8dbcd;
            border-radius: 16px;
            padding: 22px;
            box-shadow: 0 4px 14px rgba(57, 39, 31, 0.04);
        }

        .stat-card p {
            color: #806c5d;
            margin: 0 0 12px;
        }

        .stat-card h3 {
            font-size: 27px;
            margin: 0;
            overflow-wrap: anywhere;
        }

        .panel {
            margin-bottom: 25px;
        }

        .panel h3 {
            margin-top: 0;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 480px;
        }

        th,
        td {
            padding: 13px 10px;
            text-align: left;
            border-bottom: 1px solid #e8dbcd;
        }

        th {
            background: #eee1d1;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .empty {
            padding: 18px;
            color: #806c5d;
            text-align: center;
        }

        .dashboard-links {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 22px;
        }

        .dashboard-links a {
            display: inline-block;
            background: #654633;
            color: #fff8ed;
            text-decoration: none;
            border-radius: 9px;
            padding: 11px 15px;
        }

        .dashboard-links a:hover {
            background: #39271f;
        }

        footer {
            text-align: center;
            color: #806c5d;
            padding: 35px 15px;
        }

        @media (max-width: 900px) {
            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 600px) {
            header {
                align-items: flex-start;
                flex-direction: column;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .stat-card h3 {
                font-size: 24px;
            }

            .today-date h3 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>NOOK32 COFFEE</h1>
        <p>Sales and Performance Overview</p>
    </div>

    <nav>
        <a href="index.php">POS Menu</a>
        <a href="order_history.php">Order History</a>
        <a href="order_queue.php">Order Queue</a>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>

    <div class="dashboard-heading">
        <h2>Sales Dashboard</h2>

        <div class="today-date">
            <span class="today-label">TODAY</span>
            <h3><?= date('F d, Y') ?></h3>
            <p><?= date('l') ?></p>
        </div>

        <p class="subtitle">
            Daily summary of sales and payment activity.
            Only confirmed paid orders are included in sales totals.
        </p>
    </div>


    <!-- Today's sales statistics -->
    <section class="stats">

        <!-- Total Sales -->
        <article class="stat-card">
            <p>Total Sales</p>
            <h3>
                ₱<?= number_format((float) $today['sales'], 2) ?>
            </h3>
        </article>


        <!-- Paid Orders -->
        <article class="stat-card">
            <p>Paid Orders</p>
            <h3>
                <?= number_format((int) $today['orders']) ?>
            </h3>
        </article>


        <!-- Pending Payments -->
        <article class="stat-card">
            <p>Pending Payments</p>
            <h3>
                <?= number_format($paymentSummary['pending']) ?>
            </h3>
        </article>


        <!-- Failed Payments -->
        <article class="stat-card">
            <p>Failed Payments</p>
            <h3>
                <?= number_format($paymentSummary['failed']) ?>
            </h3>
        </article>


        <!-- Discounted Orders -->
        <article class="stat-card">
            <p>Discounted Orders</p>
            <h3>
                <?= number_format($discountedOrders) ?>
            </h3>
        </article>


        <!-- Total Discounts Given -->
        <article class="stat-card">
            <p>Total Discounts Given</p>
            <h3>
                ₱<?= number_format($totalDiscounts, 2) ?>
            </h3>
        </article>

    </section>


    <!-- Today's best-selling products -->
    <section class="panel">
        <h3>Today's Top-Selling Products</h3>

        <p class="subtitle">
            The five products with the highest quantities sold
            in today's confirmed paid orders.
        </p>

        <?php if ($bestResult && $bestResult->num_rows > 0): ?>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Product</th>
                            <th>Quantity Sold</th>
                            <th>Item Revenue</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $rank = 1; ?>

                        <?php while ($product = $bestResult->fetch_assoc()): ?>
                            <tr>
                                <td><?= $rank++ ?></td>

                                <td>
                                    <?= e($product['product_name']) ?>
                                </td>

                                <td>
                                    <?= number_format((int) $product['quantity_sold']) ?>
                                </td>

                                <td>
                                    ₱<?= number_format((float) $product['revenue'], 2) ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <p class="empty">
                No paid orders are available for today's sales analysis yet.
            </p>

        <?php endif; ?>
    </section>


    <!-- Navigation shortcuts -->
    <div class="dashboard-links">
        <a href="index.php">Open POS Menu</a>
        <a href="order_history.php">View Order History</a>
    </div>

</main>

<footer>
    Nook32 Coffee · POS and Sales Management System
</footer>

</body>
</html>
